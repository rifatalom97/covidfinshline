<?php
/**
 * Landing template about section
 * 
 * @author Rifat
 * 
 * @package coronavirusnetwork
 * 
 */
$slug               = get_post_meta( get_the_ID(), 'landing_page_sections', true );
$about_title        = get_post_meta( get_the_ID(), 'about_title', true );
$about_sub_title        = get_post_meta( get_the_ID(), 'about_sub_title', true );
$about_details      = get_post_meta( get_the_ID(), 'about_details', true );

$about_social_title = get_post_meta( get_the_ID(), 'about_social_title', true );
$about_facebook_url = get_post_meta( get_the_ID(), 'about_facebook_url', true );
$about_twitter_url  = get_post_meta( get_the_ID(), 'about_twitter_url', true );

?>
<section class="landing_section <?= $slug; ?>_section" id="<?= $slug; ?>_section">
    <div class="container">
        <div class="landing_container">
            <?php if($about_title !='') : ?>
                <h2 class="section_title">
                    <?= esc_html($about_title); ?>
                </h2>
            <?php endif; ?>

            <?php if($about_sub_title !='') : ?>
                <h2 class="section_sub_title">
                    <?= esc_html($about_sub_title); ?>
                </h2>
            <?php endif; ?>
            
            <?php if($about_details) : ?>
                <div class="row">
                    <div class="col-md-12 section_details">
                        <?= apply_filters('the_content', $about_details); ?>


                        <?php if($about_facebook_url || $about_twitter_url) : ?>
                            <div class="social_details clearfix">
                                <h4>
                                    <b><?= esc_html($about_social_title); ?></b>
                                </h4>

                                <?php if($about_facebook_url) : ?>
                                <a href="<?=  esc_url($about_facebook_url); ?>">
                                    <i class="fa fa-facebook"></i>
                                </a>
                                <?php endif; ?>

                                <?php if($about_twitter_url) : ?>
                                <a href="<?=  esc_url($about_twitter_url); ?>">
                                    <i class="fa fa-twitter"></i>
                                </a>
                                <?php endif; ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            
        </div>
    </div>
</section>

