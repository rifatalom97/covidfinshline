<?php

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function coronavirusnetwork_widgets_init() {

	// Right sidebar
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar Right', 'ivicdental' ),
		'id'            => 'sidebar',
		'description'   => esc_html__( 'Add right sidebar widgets.', 'ivicdental' ),
		'before_widget' => '<div id="%1$s" class="right-widget widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );



	// Footer sidebar/widget
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widgets', 'coronavirusnetwork' ),
		'id'            => 'sidebar-bottom',
		'description'   => esc_html__( 'Add footer widget here.', 'coronavirusnetwork' ),
		'before_widget' => '<!-- Single widget --><div id="%1$s" class="col-lg-4 col-md-4 col-sm-6 col-12-xs widget %2$s">',
		'after_widget'  => '</div><!--/ End Single widget -->',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'coronavirusnetwork_widgets_init' );