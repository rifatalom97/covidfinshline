<?php
/**
 * Footer template
 *
 * Contains the closing of the #content div and all content after.
 *
 * @author Rifat
 * 
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package coronavirusnetwork
 */

	$copyright_text 		= get_theme_mod( 'copyright_text' );
	$facebook_url 		= get_theme_mod( 'facebook_url' );
	$twitter_url 		= get_theme_mod( 'twitter_url' );
	$footer_right_text 		= get_theme_mod( 'footer_right_text' );
?>

		<?php if(!is_front_page() && !is_404()) : ?>
		<footer class="text-center">
			<div class="container">
			
				<?php if($facebook_url || $twitter_url) : ?>
				<div class="footer_social">
					<?php if($twitter_url) : ?>
					<a href="<?= esc_url($twitter_url); ?>"><i class="fa fa-twitter"></i></a>
					<?php endif; ?>

					<?php if($facebook_url) : ?>
					<a href="<?= esc_url($facebook_url); ?>"><i class="fa fa-facebook"></i></a>
					<?php endif; ?>
				</div>
				<?php endif; ?>

				<p class="copyright">
					<span><?= $copyright_text; ?></span>
				</p>

				
				<?php if($footer_right_text) : ?>
				<span class="footer_right_text"><?= $footer_right_text; ?></span>
				<?php endif; ?>
			</div>
		</footer>
		<?php endif; ?>

		<!-- WP Footer -->
		<?php wp_footer(); ?>
    </body>
</html>