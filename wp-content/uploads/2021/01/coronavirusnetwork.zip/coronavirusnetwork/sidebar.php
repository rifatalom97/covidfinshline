<?php
/**
 * The sidebar containing the main right widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package coronavirusnetwork
 */
if ( ! is_active_sidebar( 'sidebar' ) ) {
	return;
}
?>

<div class="col-md-4 col-lg-3 widget-area sidebar-right">
	<?php dynamic_sidebar( 'sidebar' ); ?>
</div><!-- #secondary -->
