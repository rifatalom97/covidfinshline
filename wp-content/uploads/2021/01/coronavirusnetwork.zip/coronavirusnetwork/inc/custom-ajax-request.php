<?php
/**
 * Custom ajax requests
 * 
 * @author Rifat
 * @package coronavirusnetwork
 */
// Handle contact request
add_action('wp_ajax_custom_contact_form_handle', 'process_custom_contact_form_handle');
function process_custom_contact_form_handle() {
	if ( empty($_POST) || !wp_verify_nonce($_POST['custom_contact_form_handle'],'rcustom_contact_form_handle') ) {

		$result = array('errors'=>array());

		$name 		= isset($_POST['name'])? trim($_POST['name']) : '';
		$email 		= isset($_POST['email'])? trim($_POST['email']) : '';
		$message 	= isset($_POST['message'])? trim($_POST['message']) : '';
		$website 	= isset($_POST['website'])? trim($_POST['website']) : '';

		if('' == $name){
			$result['errors']['name'] = __('Name cant\'t be empty');
		}elseif( !preg_match('/^[a-zA-Z:\- ]+$/',$name) ){
			$result['errors']['name'] = __('Name need to be valid name');
		}
		if('' == $email){
			$result['errors']['email'] = __('Email cant\'t be empty');
		}elseif( !filter_var($email, FILTER_VALIDATE_EMAIL) ){
			$result['errors']['email'] = __('Email need to be valid email');
		}
		if('' == $message){
			$result['errors']['message'] = __('Message cant\'t be empty');
		}elseif( strlen($message) < 20 || strlen($message) > 600 ){
			$result['errors']['message'] = __('Message need to be between 20-600 characters');
		}elseif( preg_match('/http|www/i',$message) ){
			$result['errors']['message'] = __('Message don\'t allowed to use url');
		}
		if($website){
			$result['errors']['message'] = __('Message don\'t allowed to use url');
		}

		if( !count($result['errors'])){
			$to = get_option('admin_email');
			$subject = __('Contact message by ','coronavirusnetwork') . $name . __(" from ",'coronavirusnetwork') . site_url();
			$headers = 'From: '. $email . "\r\n" .
				'Reply-To: ' . $email . "\r\n";
			$headers .= "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			
			$msg_body = '<html><body><div style="">';

			$msg_body .= '<h3>'.__('Contact message details are below').'</h3>';
			$msg_body .= '<table>';
				$msg_body .= '<tbody>';
					$msg_body .= '<tr>';
						$msg_body .= '<th>' . __('Name:') . '</th>';
						$msg_body .= '<td>' . $name . '</td>';
					$msg_body .= '</tr>';

					$msg_body .= '<tr>';
						$msg_body .= '<th>' . __('Email:') . '</th>';
						$msg_body .= '<td>' . $email . '</td>';
					$msg_body .= '</tr>';

					$msg_body .= '<tr>';
						$msg_body .= '<th>' . __('Message:') . '</th>';
						$msg_body .= '<td>' . $message . '</td>';
					$msg_body .= '</tr>';

				$msg_body .= '</tbody>';
			$msg_body .= '</table>';

			$msg_body .= '</div></body></html>';

			$sent = wp_mail($to, $subject, $msg_body, $headers);
			if($sent) {
				$result['success'] = __('Message sent successfully','coronavirusnetwork');
			}else  {
				$result['errors']['faild'] = __('OOP\'s! Something went wrong','coronavirusnetwork');
			}//message wasn't sent
		}

		echo json_encode( $result );

		die();
	}
}