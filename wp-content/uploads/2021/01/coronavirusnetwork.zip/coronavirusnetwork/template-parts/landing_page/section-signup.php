<?php
/**
 * Landing template about section
 * 
 * @author Rifat
 * 
 * @package coronavirusnetwork
 * 
 */
$slug               = get_post_meta( get_the_ID(), 'landing_page_sections', true );
$signup_title        = get_post_meta( get_the_ID(), 'signup_title', true );
$signup_details      = get_post_meta( get_the_ID(), 'signup_details', true );
$show_signup_button      = get_post_meta( get_the_ID(), 'show_signup_button', true );
$signup_button_text      = get_post_meta( get_the_ID(), 'signup_button_text', __('SIGN UP') );
$signup_button_url      = get_post_meta( get_the_ID(), 'signup_button_url', '#' );

?>
<section class="landing_section <?= $slug; ?>_section" id="<?= $slug; ?>_section">
    <div class="container">
        <div class="landing_container">
            <?php if($signup_title !='') : ?>
                <h2 class="section_title"><?= esc_html($signup_title); ?></h2>
            <?php endif; ?>
            
            <?php if($signup_details != '') : ?>
                <div class="row">
                    <div class="col-md-12 section_details">
                        <?= apply_filters('the_content', $signup_details); ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($show_signup_button) : ?>
                <a href="<?= esc_url($signup_button_url); ?>" class="btn btn-primary btn-lg signup_button">
                    <?= esc_html($signup_button_text); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>