<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package coronavirusnetwork
 */

 // Loading header
 get_header();
 ?>
 
 <!-- Content-area -->
 <div class="content-area single_area">

    <div class="page-header">
		<div class="container text-center">
			<h2 class="page_title"><?php the_title(); ?></h2>
		</div>
	</div>

	 <div class="container">
		 <div class="row"> 
			 <!-- Content container -->
			 <div class="<?php if( is_active_sidebar( 'sidebar' )) : ?>col-md-8 col-lg-9 <?php else : ?> col-md-12 <?php endif; ?> blog-post-area">
				 <?php
					 if ( have_posts() ) :
						 while ( have_posts() ) : the_post();
							?>
							
							<div class="post-header">
								<h1 class="page-title"><?php the_title(); ?></h1>
							</div>

							<div class="description clearfix">
							<?php the_content(); ?>
							</div>

                            <?php
                                $chapters = get_post_meta( get_the_ID(), 'info_chapters', true );

                            if( is_array($chapters) && count($chapters) ) :
                                $tab = '';
                                $tab_content = '';
                                $chapter_increment = 1;

                                $take_me = __('Take me to chapter ','coronavirusnetwork');
                                $chapter_text = __('Chapter ','coronavirusnetwork');
                                foreach( $chapters as $chapter ){
                                    $color = $chapter['info_chapters_color']? : '#8b9eb8';
                                    $tab .= "<div class='col-md-4 col-sm-6 col-xs-12 single-chapter-tab'><a href='#chapter-{$chapter_increment}' style='background-color: {$color}'>{$chapter['info_chapters_tab_title']}<strong>{$take_me} {$chapter_increment}</strong></a></div>";

                                    $tab_content .= "<div class='single-chapter' id='chapter-{$chapter_increment}'><h2 class='chapter-title' style='background-color: {$color}'><span>{$chapter_text} {$chapter_increment} : </span> {$chapter['info_chapters_title']}</h2><div class='chapter-content'>{$chapter['info_chapters_content']}</div></div>";

                                    $chapter_increment++;
                                }
                            ?>
                             <div class="chapters">
                                 <div class="clearfix tabs"><?php echo $tab; ?></div>

                                 <div class="row clearfix"><div class="col-md-12"></div></div>

                                 <div class="row tab-content">
                                    <div class="col-md-12">
                                        <?php echo $tab_content; ?>
                                    </div>
                                 </div>
                             </div>
                             <?php endif; ?>

							<div class="clearfix"></div>

							<?php comments_template(); ?>

						<?php endwhile;
					 else :
						 get_template_part( 'template-parts/content', 'none' );
					 endif;
				 ?>
			 </div><!-- #main -->


             <!-- Getting right sidebar -->
             <?php get_sidebar('right'); ?>
             <!-- End Right sidebar -->

		 </div>
	 </div>
 </div>
 <!-- End content area -->
 
 <!-- Footer -->
 <?php
 get_footer();