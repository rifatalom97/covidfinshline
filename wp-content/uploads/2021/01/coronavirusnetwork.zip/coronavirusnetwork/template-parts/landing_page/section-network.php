<?php
/**
 * Landing template network section
 * 
 * @author Rifat
 * 
 * @package coronavirusnetwork
 * 
 */
$slug               = get_post_meta( get_the_ID(), 'landing_page_sections', true );
$network_title        = get_post_meta( get_the_ID(), 'network_title', true );
$network_details      = get_post_meta( get_the_ID(), 'network_details', true );
$network_map_img      = get_post_meta( get_the_ID(), 'network_map_img', true );

$network_partners      = get_post_meta( get_the_ID(), 'repeatable_network_partners', true );
$network_networks      = get_post_meta( get_the_ID(), 'network_networks_group', true );

?>
<section class="landing_section <?= $slug; ?>_section" id="<?= $slug; ?>_section">
    <div class="container">
        <div class="landing_container">
            <?php if($network_title !='') : ?>
                <h2 class="section_title">
                    <?= esc_html($network_title); ?>
                </h2>
            <?php endif; ?>
            
            <?php if($network_details != '') : ?>
            <div class="row">
                <div class="col-md-12 section_details">
                    <?= apply_filters('the_content', $network_details); ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if($network_networks && count($network_networks)) : ?>
                <div class="network_networks">

                    <?php if(isset($network_networks[0])) : ?>
                    <div class="clearfix one_piece">
                        <div class="network_single_item">
                            <div class="network_inner">
                                <h4><?= $network_networks[0]['network_name']; ?></h4>
                                <p><?= esc_html($network_networks[0]['network_details']); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($network_networks[1])) : ?>
                    <div class="clearfix two_piece">
                        <div class="network_single_item">
                            <div class="network_inner">
                                <h4><?= $network_networks[1]['network_name']; ?></h4>
                                <p><?= esc_html($network_networks[1]['network_details']); ?></p>
                            </div>
                        </div>
                        <?php if(isset($network_networks[2])) : ?>
                        <div class="network_single_item">
                            <div class="network_inner">
                                <h4><?= $network_networks[2]['network_name']; ?></h4>
                                <p><?= esc_html($network_networks[2]['network_details']); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                </div>
            <?php endif; ?>

            <?php if($network_map_img) : ?>
                <img src="<?= esc_url($network_map_img); ?>" alt="<?= esc_html($network_title); ?>">
            <?php endif; ?>


            <?php if($network_partners && count($network_partners)) : ?>
                <div class="network_partners">
                    <div class="owl-carousel owl-theme">
                        <?php foreach($network_partners as $partner) : ?>
                            <div class="item">
                                <img src="<?= esc_url($partner['single_network_partner_logo']); ?>" alt="<?= esc_attr($partner['single_network_partner_name']); ?>">
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>