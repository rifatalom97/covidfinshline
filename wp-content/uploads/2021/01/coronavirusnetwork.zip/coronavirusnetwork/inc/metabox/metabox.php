<?php
/**
 * Metabox for coronavirusnetwork
 * 
 * @author Rifat
 * @package coronavirusnetwork
 */

// Metabox for coronavirusnetwork
add_action( 'cmb2_admin_init', 'coronavirusnetwork_metabox' );
function coronavirusnetwork_metabox(){
        

        /**###########################################################
                Common page metabox
        #############################################################*/
        // Custom Metabox for pages
        $page_sidebar = new_cmb2_box( array(
                'id'            => '_page_sidebar',
                'title'         => __( 'Page Option', 'cmb2' ),
                'object_types'  => array( 'page', ),
                'context'      => 'side',
                'priority'     => 'default',
                'show_names'   => true,
                'preview_size' => array( 60, 60 ),
        ) );
	$page_sidebar->add_field(array(
                'name' => __( 'Select Sidebar', 'cmb2' ),
                'desc' => false,
                'id'   => 'page_sidebar',
                'type' => 'select',
                'options' => array(
						'fullwidth' => 'Full width',
                        'sidebar' => 'Sidebar',
                )
        ));
        $page_sidebar->add_field(array(
                'name' => __( 'Hide page title', 'cmb2' ),
                'desc' => false,
                'id'   => 'page_title',
                'type' => 'radio',
                'options' => array(
                        '1' => 'Yes',
                        '0' => 'No',
                ),
                'default' => 1,
        ));

        $page_sidebar->add_field(array(
                'name' => __( 'Gray color page', 'cmb2' ),
                'desc' => false,
                'id'   => 'gray_color_page',
                'type' => 'radio',
                'options' => array(
                        '1' => 'Yes',
                        '0' => 'No',
                ),
                'default' => 0,
        ));
        /**###########################################################
                End common page meta
        #############################################################*/





        

        /**###########################################################
                Front page Widgets metaboxes
        #############################################################*/

        // Custom landing_page page template controll by metabox
        $landing_page_widget = new_cmb2_box( array(
                'id'            => 'coronavirusnetwork_landing_page_widgets',
                'title'         => __( 'Sections', 'cmb2' ),
                'object_types'  => array( 'landing_page', ),
                'show_on'       => array(),
        ) );
        $landing_page_widget->add_field( array(
                'name'          => __( 'Select widgets', 'cmb2' ),
                'desc'          => __( 'Add your landing page widgets section', 'cmb2' ),
                'id'            => 'landing_page_sections',
                'type'          => 'select',
                'default'       => '',
                'options'       => array(
                        ''              => 'Select section',
                        'about'         => 'About',
                        'mission'       => 'Mission',
                        'signup'        => 'Sign Up',
                        'network'       => 'Network',
                        'contact'       => 'Contact',
                )
        ) );

        // About
        $about = new_cmb2_box( array(
                'id'            => 'about_section',
                'title'         => __( 'About section', 'cmb2' ),
                'object_types'  => array( 'landing_page', ),
                'show_on_cb'    => 'cmb_only_show_for_about',
        ) );
        
        
        $about->add_field( array(
                'name' => __( 'Title', 'cmb2' ),
                'desc' => __( 'Add about section title', 'cmb2' ),
                'id'   => 'about_title',
                'type' => 'text',
        ) );
        $about->add_field( array(
                'name' => __( 'Sub-Title', 'cmb2' ),
                'desc' => __( 'Add about section sub-title', 'cmb2' ),
                'id'   => 'about_sub_title',
                'type' => 'text',
        ) );
        $about->add_field( array(
                'name'          => __( 'Details', 'cmb2' ),
                'desc'          => __( 'Add about section details', 'cmb2' ),
                'id'            => 'about_details',
                'type'          => 'wysiwyg',
                'options'       => array(
                        'textarea_rows' => 8, // rows="..."
                        'tinymce'       => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
                        'quicktags'     => true // load Quicktags, can be used to pass settings directly to Quicktags using an array()
                    ),
        ) );

        $about->add_field( array(
                'name'          => __( 'Social Title', 'cmb2' ),
                'desc'          => __( 'Add about section social title', 'cmb2' ),
                'id'            => 'about_social_title',
                'type'          => 'text',
                'default'       => __('#PROJECTFINISHLINE'),
        ) );
        $about->add_field( array(
                'name'          => __( 'Facebook Url', 'cmb2' ),
                'desc'          => __( 'Add about section social facebook url', 'cmb2' ),
                'id'            => 'about_facebook_url',
                'type'          => 'text_url',
                'attributes'    => array(
                        'placeholder' => 'https://facebook.com/example'
                ),
        ) );
        $about->add_field( array(
                'name'          => __( 'Twitter Url', 'cmb2' ),
                'desc'          => __( 'Add about section social twitter url', 'cmb2' ),
                'id'            => 'about_twitter_url',
                'type'          => 'text_url',
                'attributes'    => array(
                        'placeholder' => 'https://twitter.com/example'
                ),
        ) );

        /**
         * Only display a metabox if the page's 'status' is 'about'
         * @param  object $cmb CMB2 object
         * @return bool        True/false whether to show the metabox
         */
        function cmb_only_show_for_about( $cmb ) {
                $status = get_post_meta( $cmb->object_id(), 'landing_page_sections', 1 );
                // Only show if status is 'external'
                return 'about' === $status;
        }
        // End about



        // Mission
        $mission = new_cmb2_box( array(
                'id'            => 'mission_section',
                'title'         => __( 'Mission section', 'cmb2' ),
                'object_types'  => array( 'landing_page', ),
                'show_on_cb' => 'cmb_only_show_for_mission',
        ) );
        $mission->add_field( array(
                'name' => __( 'Title', 'cmb2' ),
                'desc' => __( 'Add mission section title', 'cmb2' ),
                'id'   => 'mission_title',
                'type' => 'text',
        ) );
        $mission->add_field( array(
                'name' => __( 'Details', 'cmb2' ),
                'desc' => __( 'Add mission section details', 'cmb2' ),
                'id'   => 'mission_details',
                'type' => 'wysiwyg',
                'options' => array(
                        'textarea_rows' => 8, // rows="..."
                        'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
                        'quicktags' => true // load Quicktags, can be used to pass settings directly to Quicktags using an array()
                    ),
        ) );
        $mission_repeatable_group = $mission->add_field( array(
		'id'          => 'repeatable_missions',
		'type'        => 'group',
		'description' => __( 'Add missions', 'cmb2' ),
		'options'     => array(
			'group_title'   => __( 'Mission {#}', 'cmb2' ),
			'add_button'    => __( 'Add Another mission', 'cmb2' ),
			'remove_button' => __( 'Remove mission', 'cmb2' ),
			'sortable'      => true,
			'closed'     => true
		),
	) );

	$mission->add_group_field( $mission_repeatable_group, array(
		'name'       => __( 'Title', 'cmb2' ),
		'id'         => 'single_mission_title',
		'type'       => 'textarea_small',
        ) );
        $mission->add_group_field( $mission_repeatable_group, array(
		'name'       => __( 'Icon', 'cmb2' ),
		'id'         => 'single_mission_icon',
		'type'          => 'file',
                'options' => array(
                        'url' => true,
                ),
                'text'    => array(
                        'add_upload_file_text' => 'Add Icon' 
                ),
                'query_args' => array(
                        'type' => array(
                                'image/jpeg',
                                'image/png',
                        ),
                ),
                'preview_size' => 'medium', // Image size to use when previewing in the admin.
	) );
        
        /**
         * Only display a metabox if the page's 'status' is 'mission'
         * @param  object $cmb CMB2 object
         * @return bool        True/false whether to show the metabox
         */
        function cmb_only_show_for_mission( $cmb ) {
                $status = get_post_meta( $cmb->object_id(), 'landing_page_sections', 1 );
                // Only show if status is 'external'
                return 'mission' === $status;
        }
        // End mission



        // SignUp
        $signup = new_cmb2_box( array(
                'id'            => 'signup_section',
                'title'         => __( 'SignUp section', 'cmb2' ),
                'object_types'  => array( 'landing_page', ),
                'show_on_cb' => 'cmb_only_show_for_signup',
        ) );
        $signup->add_field( array(
                'name' => __( 'Title', 'cmb2' ),
                'desc' => __( 'Add signup section title', 'cmb2' ),
                'id'   => 'signup_title',
                'type' => 'text',
        ) );
        $signup->add_field( array(
                'name' => __( 'Details', 'cmb2' ),
                'desc' => __( 'Add signup section details', 'cmb2' ),
                'id'   => 'signup_details',
                'type' => 'wysiwyg',
                'options' => array(
                        'textarea_rows' => 8, // rows="..."
                        'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
                        'quicktags' => true // load Quicktags, can be used to pass settings directly to Quicktags using an array()
                    ),
        ));

        $signup->add_field( array(
                'name' => __( 'Show SignUp Button', 'cmb2' ),
                'desc' => __( '', 'cmb2' ),
                'id'   => 'show_signup_button',
                'type' => 'radio_inline',
                'options' => array(
                        true => __('Yes','cmb2'),
                        false => __('No','cmb2'),
                ),
                'default' => true
        ) );
        $signup->add_field( array(
                'name' => __( 'Button Text', 'cmb2' ),
                'desc' => __( 'Add signup button text', 'cmb2' ),
                'id'   => 'signup_button_text',
                'type' => 'text',
                'default' => __('SIGN UP')
        ) );
        $signup->add_field( array(
                'name' => __( 'Button Url', 'cmb2' ),
                'desc' => __( 'Add signup button url', 'cmb2' ),
                'id'   => 'signup_button_url',
                'type' => 'text_url',
                'attributes' => array(
                        'placeholder' => 'https://example.com/signup'
                ),
        ) );
        
        /**
         * Only display a metabox if the page's 'status' is 'signup'
         * @param  object $cmb CMB2 object
         * @return bool        True/false whether to show the metabox
         */
        function cmb_only_show_for_signup( $cmb ) {
                $status = get_post_meta( $cmb->object_id(), 'landing_page_sections', 1 );
                // Only show if status is 'external'
                return 'signup' === $status;
        }
        // End signup


        
        // Network
        $network = new_cmb2_box( array(
                'id'            => 'network_section',
                'title'         => __( 'Network section', 'cmb2' ),
                'object_types'  => array( 'landing_page', ),
                'show_on_cb' => 'cmb_only_show_for_network',
        ) );
        $network->add_field( array(
                'name' => __( 'Title', 'cmb2' ),
                'desc' => __( 'Add network section title', 'cmb2' ),
                'id'   => 'network_title',
                'type' => 'text',
        ) );
        $network->add_field( array(
                'name' => __( 'Details', 'cmb2' ),
                'desc' => __( 'Add network section details', 'cmb2' ),
                'id'   => 'network_details',
                'type' => 'wysiwyg',
        ) );

        
        $network_networks_group = $network->add_field( array(
		'id'          => 'network_networks_group',
		'type'        => 'group',
		'description' => __( 'Add networks how you communicated', 'cmb2' ),
		'options'     => array(
                        'group_title'   => __( 'Network {#}', 'cmb2' ),
                        'add_button'    => __( 'Add another network', 'cmb2' ),
                        'remove_button' => __( 'Remove network', 'cmb2' ),
                        'sortable'      => true,
                        'closed'     => true
		),
	) );

	$network->add_group_field( $network_networks_group, array(
		'name'       => __( 'Name', 'cmb2' ),
		'id'         => 'network_name',
		'type'       => 'text',
        ) );
        $network->add_group_field( $network_networks_group, array(
		'name'       => __( 'Icon', 'cmb2' ),
		'id'         => 'network_details',
		'type'          => 'textarea_small',
                'preview_size' => 'medium', // Image size to use when previewing in the admin.
	) );


        $network->add_field( array(
		'name'       => __( 'Network Map', 'cmb2' ),
		'id'         => 'network_map_img',
		'type'          => 'file',
                'options' => array(
                        'url' => true,
                ),
                'text'    => array(
                        'add_upload_file_text' => 'Add Map Image' 
                ),
                'query_args' => array(
                        'type' => array(
                                'image/jpeg',
                                'image/png',
                        ),
                ),
                'preview_size' => 'large', // Image size to use when previewing in the admin.
	) );
        $network_repeatable_group = $network->add_field( array(
		'id'          => 'repeatable_network_partners',
		'type'        => 'group',
		'description' => __( 'Add network partners', 'cmb2' ),
		'options'     => array(
			'group_title'   => __( 'Partner {#}', 'cmb2' ),
			'add_button'    => __( 'Add another partner', 'cmb2' ),
			'remove_button' => __( 'Remove partner', 'cmb2' ),
			'sortable'      => true,
			'closed'     => true
		),
	) );

	$network->add_group_field( $network_repeatable_group, array(
		'name'       => __( 'Name', 'cmb2' ),
		'id'         => 'single_network_partner_name',
		'type'       => 'text',
        ) );
        $network->add_group_field( $network_repeatable_group, array(
		'name'       => __( 'Icon', 'cmb2' ),
		'id'         => 'single_network_partner_logo',
		'type'          => 'file',
                'options' => array(
                        'url' => true,
                ),
                'text'    => array(
                        'add_upload_file_text' => 'Add Partner Logo' 
                ),
                'query_args' => array(
                        'type' => array(
                                'image/jpeg',
                                'image/png',
                        ),
                ),
                'preview_size' => 'medium', // Image size to use when previewing in the admin.
	) );
        
        /**
         * Only display a metabox if the page's 'status' is 'network'
         * @param  object $cmb CMB2 object
         * @return bool        True/false whether to show the metabox
         */
        function cmb_only_show_for_network( $cmb ) {
                $status = get_post_meta( $cmb->object_id(), 'landing_page_sections', 1 );
                // Only show if status is 'external'
                return 'network' === $status;
        }
        // End network



        // Contact
        $contact = new_cmb2_box( array(
                'id'            => 'contact_section',
                'title'         => __( 'Contact section', 'cmb2' ),
                'object_types'  => array( 'landing_page', ),
                'show_on_cb' => 'cmb_only_show_for_contact',
        ) );
        $contact->add_field( array(
                'name' => __( 'Title', 'cmb2' ),
                'desc' => __( 'Add contact section title', 'cmb2' ),
                'id'   => 'contact_title',
                'type' => 'text',
        ) );
        $contact->add_field( array(
                'name' => __( 'Details', 'cmb2' ),
                'desc' => __( 'Add contact section details', 'cmb2' ),
                'id'   => 'contact_details',
                'type' => 'wysiwyg',
        ) );
        $contact->add_field( array(
                'name' => __( 'Contact Form', 'cmb2' ),
                'desc' => __( '', 'cmb2' ),
                'id'   => 'contact_form_show',
                'type' => 'radio_inline',
                'options' => array(
                        true => __( 'Show', 'cmb2' ),
                        false   => __( 'Hide', 'cmb2' ),
                ),
                'default' => true,
        ) );
        $contact->add_field( array(
                'name' => __( 'Download title', 'cmb2' ),
                'desc' => __( 'Add contact downlaod title', 'cmb2' ),
                'id'   => 'contact_download_title',
                'type' => 'textarea_small',
                'default' => '<b>Download</b> the Project Finish Line 
                PDF for more information',
        ) );
        $contact->add_field( array(
                'name' => __( 'Downloadable file', 'cmb2' ),
                'desc' => __( 'Add downlaodable file', 'cmb2' ),
                'id'   => 'contact_download_file',
                'type' => 'file',
                'default' => '#',
        ) );
        $contact->add_field( array(
                'name' => __( 'Footer Text', 'cmb2' ),
                'desc' => __( 'Add footer text', 'cmb2' ),
                'id'   => 'contact_footer_text',
                'type' => 'textarea_small',
                'default' => '',
        ) );
        /**
         * Only display a metabox if the page's 'status' is 'contact'
         * @param  object $cmb CMB2 object
         * @return bool        True/false whether to show the metabox
         */
        function cmb_only_show_for_contact( $cmb ) {
                $status = get_post_meta( $cmb->object_id(), 'landing_page_sections', 1 );
                // Only show if status is 'external'
                return 'contact' === $status;
        }
        // End contact

        /**###########################################################
                End Front page widgets
        #############################################################*/

}