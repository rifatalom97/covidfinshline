/**
 * Single Page Nav Plugin
 * Copyright (c) 2013 Chris Wojcik <hello@chriswojcik.net>
 * Dual licensed under MIT and GPL.
 * @author Chris Wojcik
 * @version 1.1.0
 */
if(typeof Object.create!=="function"){Object.create=function(e){function t(){}t.prototype=e;return new t}}(function(e,t,n,r){"use strict";var i={init:function(n,r){this.options=e.extend({},e.fn.singlePageNav.defaults,n);this.container=r;this.$container=e(r);this.$links=this.$container.find("a");if(this.options.filter!==""){this.$links=this.$links.filter(this.options.filter)}this.$window=e(t);this.$htmlbody=e("html, body");this.$links.on("click.singlePageNav",e.proxy(this.handleClick,this));this.didScroll=false;this.checkPosition();this.setTimer()},handleClick:function(t){var n=this,r=t.currentTarget,i=e(r.hash);t.preventDefault();if(i.length){n.clearTimer();if(typeof n.options.beforeStart==="function"){n.options.beforeStart()}n.setActiveLink(r.hash);n.scrollTo(i,function(){if(n.options.updateHash&&history.pushState){history.pushState(null,null,r.hash)}n.setTimer();if(typeof n.options.onComplete==="function"){n.options.onComplete()}})}},scrollTo:function(e,t){var n=this;var r=n.getCoords(e).top;var i=false;n.$htmlbody.stop().animate({scrollTop:r},{duration:n.options.speed,easing:n.options.easing,complete:function(){if(typeof t==="function"&&!i){t()}i=true}})},setTimer:function(){var e=this;e.$window.on("scroll.singlePageNav",function(){e.didScroll=true});e.timer=setInterval(function(){if(e.didScroll){e.didScroll=false;e.checkPosition()}},250)},clearTimer:function(){clearInterval(this.timer);this.$window.off("scroll.singlePageNav");this.didScroll=false},checkPosition:function(){var e=this.$window.scrollTop();var t=this.getCurrentSection(e);this.setActiveLink(t)},getCoords:function(e){return{top:Math.round(e.offset().top)-this.options.offset}},setActiveLink:function(e){var t=this.$container.find("a[href='"+e+"']");if(!t.hasClass(this.options.currentClass)){this.$links.removeClass(this.options.currentClass);t.addClass(this.options.currentClass)}},getCurrentSection:function(t){var n,r,i,s;for(n=0;n<this.$links.length;n++){r=this.$links[n].hash;if(e(r).length){i=this.getCoords(e(r));if(t>=i.top-this.options.threshold){s=r}}}return s||this.$links[0].hash}};e.fn.singlePageNav=function(e){return this.each(function(){var t=Object.create(i);t.init(e,this)})};e.fn.singlePageNav.defaults={offset:0,threshold:120,speed:400,currentClass:"current",easing:"swing",updateHash:false,filter:"",onComplete:false,beforeStart:false}})(jQuery,window,document)

jQuery(document).ready(function($){
    // loading mobile menu
    mobile_menu();
});


// mobile menu
function mobile_menu(){
    var btn = jQuery('.mobile-menu');
    btn.on('click', function(){
       //jQuery('body').find( '.nav' ).fadeIn();
        jQuery(this).toggleClass('active');
        jQuery('body').find( 'nav.nav' ).toggleClass('open');
    });
}


jQuery(document).ready(function(){
    var hm_menus = jQuery('body').find('.hm-section-menu');
    var hm_section = jQuery('body').find('.hm_section');
    if( hm_menus.length && hm_section.length ){
        jQuery('header ul .hm-section-menu:first-child').children().addClass('hm-current');
    }
    jQuery('header .menu li.hm-section-menu a').click(function(){
        jQuery(this).addClass('hm-current');
        jQuery(this).parent().siblings().children().removeClass('hm-current');

        if( !jQuery('body').hasClass('home') ){            
            window.location = jQuery(this).attr('href');
        }
    });
});


// The actual plugin
jQuery('.menu').singlePageNav({
    offset: (screen.width < 993)? 50 : 80,
    filter: ':not(.external a)',
    updateHash: true,
    threshold: 20,
    beforeStart: function() {
        // console.log('begin scrolling');
    },
    onComplete: function(elem) {
        // console.log(elem);
    }
});

jQuery(document).scroll(function(e){
    var w_top = jQuery(window).scrollTop();
    var off_top = 50;
    jQuery('.hm_section').each(function(){
        var d_top = jQuery(this).offset().top;
        var d_height = jQuery(this).outerHeight();
        if( w_top >= (d_top-off_top) && w_top < (d_top+d_height) ){
            var m_id = jQuery(this).attr('id');
            jQuery('.hm-section-menu').each(function(){
                if( jQuery(this).children().attr('href').indexOf('#'+m_id) > -1 ){
                    jQuery(this).children().addClass('hm-current');
                    jQuery(this).siblings().children().removeClass('hm-current');
                }
            });
        }
        
        
    });
    //console.log( w_top + ' ' + d_height + ' ' + d_top );
});

// Audo hide navigation menu after click on mideum screen
jQuery(function($){
    var w_size = window.screen.width;
    if( w_size < 992 ){
        jQuery('.menu li a').on('click',function(){
            setTimeout(function(){
                jQuery('.mobile-menu').removeClass('active');
                jQuery('.nav').removeClass('open');
            }, 200);
        });
    }
});



// On scroll Navigation menu effect
// nav scrolling effect
nav_srolling_effect();
jQuery(window).scroll(function(){
    // nav scrolling effect
    nav_srolling_effect();
});

function nav_srolling_effect(){
    var scroll = jQuery(window).scrollTop();
    var opacity = 0;
    var padding = 10-(scroll/5);
        
    opacity = (scroll>100)? 100 : scroll-20;

    padding = (padding<2)? 2 : padding;

    if(scroll>70){
        jQuery( 'header' ).addClass('scroling');
    }else{
        jQuery( 'header' ).removeClass('scroling');
    }
    jQuery( 'header' ).css('background-color','rgba(29,88,176,'+opacity+'% )');
    jQuery( 'header' ).css('padding',padding+'px');

    jQuery( '#primary-menu' ).css('top',jQuery( 'header' ).outerHeight());
}
// Cloase nav menu outside click
jQuery(document).click(function(event) { 
    var $target = jQuery(event.target);
    if(!$target.closest('.menu-area').length) {
        jQuery('.mobile-menu').click();
    }
});


// Submit contact form
jQuery(document).ready(function(){
    jQuery('.custom_contact_form').on('submit',function(){
        var t = jQuery(this);

        jQuery.ajax({
            url: t.attr('action'),
            method: 'POST',
            dataType: 'JSON',
            data: t.serializeArray(),
            beforeSend:function(){
                t.find('button').html('Wait...');
                t.find('button').attr('disabled','disabled');
            },
            success: function(response){
                if(response.errors){
                    if(response.errors.name){
                        jQuery('#name_error').html( response.errors.name );
                    }
                    if(response.errors.email){
                        jQuery('#email_error').html( response.errors.email );
                    }
                    if(response.errors.message){
                        jQuery('#message_error').html( response.errors.message );
                    }
                    if(response.errors.faild){
                        jQuery('#message_error').html( response.errors.faild );
                    }
                }

                if( response.success ){
                    jQuery('input[name="name"],input[name="email"], textarea').val('');

                    jQuery('.success_msg').html(response.success);
                    jQuery('.success_msg').fadeIn(300);
                    setTimeout(function(){
                        jQuery('.success_msg').fadeOut(300);
                    },2000);
                }

                t.find('button').html('SUBMIT');
                t.find('button').removeAttr('disabled');
            },
            errors:function(e){
                console.log(e);
            }
        });

        return false;
    });

    jQuery('.custom_contact_form input, .custom_contact_form textarea').on('keyup keydown focus',function(){
        jQuery(this).next('p').html('');
    });
});



jQuery('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    dots:false,
    autoplay:true,
    autoHeight:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})