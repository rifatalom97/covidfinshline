<?php
/**
 * Custom Taxonomy
 * 
 * @author Rifat
 * @package coronavirusnetwork
 * 
 */

//hook into the init action and call create_topics_nonhierarchical_taxonomy when it fires

add_action( 'init', 'coronavirusnetwork_custom_taxonomy', 0 );
 
function coronavirusnetwork_custom_taxonomy() {
 
  // Labels part for the GUI
  $labels = array(
    'name' => _x( 'Category', 'taxonomy general name' ),
    'singular_name' => _x( 'Category', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search category' ),
    'popular_items' => __( 'Popular Category' ),
    'all_items' => __( 'All Category' ),
    'parent_item' => null,
    'parent_item_colon' => null,
    'edit_item' => __( 'Edit Category' ), 
    'update_item' => __( 'Update Category' ),
    'add_new_item' => __( 'Add New Category' ),
    'new_item_name' => __( 'New Category Name' ),
    'separate_items_with_commas' => __( 'Separate category with commas' ),
    'add_or_remove_items' => __( 'Add or remove category' ),
    'choose_from_most_used' => __( 'Choose from the most used category' ),
    'menu_name' => __( 'Category' ),
  ); 
    // Now register the non-hierarchical taxonomy like tag
   register_taxonomy('product_category','products',array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'update_count_callback' => '_update_post_term_count',
    'query_var' => true,
    'rewrite' => array( 'slug' => 'product-category' ),
  ));

}