<?php
/**
 *  Template Name: Landing
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 * @author Rifat
 * @package coronavirusnetwork
 */

 // Loading header
get_header(); ?>

<!-- Section -->
<?php
    global $wp_posts;
    $args = array( 'post_type' =>'landing_page', 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby'=>'menu_order id', 'order'=>'ASC' );
    $query = new WP_Query( $args );

    if( $query->have_posts() ) :
        while($query->have_posts()) : $query->the_post();
            $slug = get_post_meta( get_the_ID(), 'landing_page_sections', true );
            
            get_template_part( 'template-parts/landing_page/section', $slug );
            
        endwhile;
    endif; 
?>
<!-- End Section -->

<!-- Footer -->
<?php
get_footer();
