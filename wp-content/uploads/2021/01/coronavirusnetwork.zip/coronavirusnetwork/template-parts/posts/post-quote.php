<?php
  $postClass = is_active_sidebar( 'sidebar' )? 'col-md-12 col-lg-6' : 'col-md-6';
?>
<div <?php post_class("blog-post index-blog-post {$postClass} clearfix"); ?> id="post-<?php the_ID(); ?>">
  <div class="post-inner-container">
    <div class="post-description quote">
        
        <blockquote><i class="fa fa-quote-left"></i>
        <?php echo strip_tags(get_the_content()); ?>
        <i class="fa fa-quote-right"></i></blockquote>
        
        <p>-- <?php the_title(); ?></p>
    </div>
  </div>
</div>