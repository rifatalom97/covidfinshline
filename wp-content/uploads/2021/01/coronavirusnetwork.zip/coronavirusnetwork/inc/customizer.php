<?php
/**
 * coronavirusnetwork Theme Customizer
 *
 * @package coronavirusnetwork
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function coronavirusnetwork_customize_register( $wp_customize ) {

	$wp_customize->add_section( 'nav_menus_custom', array(
        'title' => __( 'Menu extra settings', 'nssra' ),
        'panel' => 'nav_menus'
    ) );
	// Header menu
	$wp_customize->add_setting(
        'visibile_hm_sections_menu',
        array(
			'default'     => '1',
			'transport'  =>  'refresh'
        )
    );
    $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'visibile_hm_sections_menu',
            array(
                'label'      => __( 'Show home sections on menu', 'coronavirusnetwork' ),
                'section'    => 'nav_menus_custom',
				'settings'   => 'visibile_hm_sections_menu',
				'type'		=> 'radio',
				'choices'   => array(
					'1'	=> 'Yes',
					'0'	=> 'No'
				)
            )
        )
	);




	// Footer settings
	$wp_customize->add_section(
		'footer_section',
		array(
			'title' => __('Footer settings', 'coronavirusnetwork')
		)
	);

	$wp_customize->add_setting(
        'twitter_url',
        array(
			'default'     => __('','coronavirusnetwork'),
			'transport'  =>  'refresh'
        )
    );
    $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'twitter_url',
            array(
                'label'      => __( 'Twitter url', 'coronavirusnetwork' ),
                'section'    => 'footer_section',
				'settings'   => 'twitter_url',
				'type'		=> 'url',
				'input_attrs' => array(
					'placeholder' => __( 'https://twitter.com', 'coronavirusnetwork' ),
				),
				'default'     => 'https://twitter.com'
            )
        )
	);
	$wp_customize->add_setting(
        'facebook_url',
        array(
			'default'     => __('','coronavirusnetwork'),
			'transport'  =>  'refresh'
        )
    );
    $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'facebook_url',
            array(
                'label'      => __( 'Facebook url', 'coronavirusnetwork' ),
                'section'    => 'footer_section',
				'settings'   => 'facebook_url',
				'type'		=> 'url',
				'input_attrs' => array(
					'placeholder' => __( 'https://facebook.com', 'coronavirusnetwork' ),
				),
				'default'     => 'https://facebook.com'
            )
        )
	);

	$wp_customize->add_setting(
        'copyright_text',
        array(
			'default'     => __('&copy; Copyright by covidfinishline.com','coronavirusnetwork'),
			'transport'  =>  'refresh'
        )
    );
    $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'copyright_text',
            array(
                'label'      => __( 'Copyright Text', 'coronavirusnetwork' ),
                'section'    => 'footer_section',
				'settings'   => 'copyright_text',
				'type'		=> 'text',
            )
        )
	);


	$wp_customize->add_setting(
        'footer_right_text',
        array(
			'default'     => __('Some text','coronavirusnetwork'),
			'transport'  =>  'refresh'
        )
    );
    $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'footer_right_text',
            array(
                'label'      => __( 'Footer right text', 'coronavirusnetwork' ),
                'section'    => 'footer_section',
				'settings'   => 'footer_right_text',
				'type'		=> 'text',
            )
        )
	);
	// End of footer
	


	 //=============================================================
	// Remove header image and widgets option from theme customizer
	//=============================================================
	$wp_customize->remove_control("header_image");

	//=============================================================
	// Remove Colors, Background image, and Static front page 
	// option from theme customizer     
	//=============================================================
	$wp_customize->remove_section("colors");
	$wp_customize->remove_section("background_image");
	$wp_customize->remove_section("static_front_page");


	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'        => '.site-title a',
			'render_callback' => 'coronavirusnetwork_customize_partial_blogname',
		) );
		$wp_customize->selective_refresh->add_partial( 'blogdescription', array(
			'selector'        => '.site-description',
			'render_callback' => 'coronavirusnetwork_customize_partial_blogdescription',
		) );
	}

}
add_action( 'customize_register', 'coronavirusnetwork_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function coronavirusnetwork_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function coronavirusnetwork_customize_partial_blogdescription() {
	bloginfo( 'description' );
}





/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function coronavirusnetwork_customize_preview_js() {
	wp_enqueue_script( 'coronavirusnetwork-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'coronavirusnetwork_customize_preview_js' );
