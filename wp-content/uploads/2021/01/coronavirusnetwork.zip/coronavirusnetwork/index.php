<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package coronavirusnetwork
 */

 // Loading header
 get_header();  ?>

 <!-- Content-area -->
 <div class="content-area index_area">

 	<div class="page-header">
		<div class="container text-center">
			<h2 class="page_title">
				<?php 
					if(is_home()){
						_e('Blog','coronavirusnetwork');
					}else{
						the_title();
					}
				?>
			</h2>
		</div>
	</div>

	 <div class="container">
		 <div class="row">
			 <!-- Content container -->
			 <div class="<?php if( is_active_sidebar( 'sidebar' ) ) : ?>col-md-8 col-lg-9<?php else : ?> col-md-12 <?php endif; ?>">
				 <?php if ( have_posts() ) : ?>
					<div class="blog-posts row">
						<?php  while ( have_posts() ) : the_post(); ?>
							<div <?php post_class('grid-blog-post col-md-6'); ?> id="post-<?php the_ID(); ?>">
								<?php if(has_post_format( 'aside' )) : ?>
									<div class="row">
										<?php if( has_post_thumbnail() ) : ?>
											<div class="col-md-4">
												<?php the_post_thumbnail('medium', array('class'=>'img-responsive')); ?>
											</div>
										<?php endif; ?>
										<div class="<?= has_post_thumbnail()? 'col-md-8' : 'col-md-12'; ?>">
											<div>
												<h2 class="post-title">
													<a href="<?php the_permalink(); ?>">
														<?php the_title(); ?>
													</a>
												</h2>
												<p class="post-info">
													<span><i class="fa fa-user"></i> <?= get_the_author(); ?> </span>
													<span><i class="fa fa-clock-o"></i> <?php the_date('d M, Y'); ?> </span>
													<span><?php comments_popup_link('<i class="fa fa-comments-o"></i> 0','<i class="fa fa-comments-o"></i> 1','<i class="fa fa-comments-o"></i> %'); ?></span>
												</p>
											</div>

											<div class="post-desc">
												<?php the_content(); ?>
											</div>
										</div>
									</div>
								<?php elseif(has_post_format( 'link' )) : ?>
								
										<div class="post-desc">
											<?php if(has_excerpt()) : ?>
												<p><?php the_excerpt(); ?></p>
											<?php else : ?>
												<?php the_content('Continue reading...'); ?>
											<?php endif; ?>
											
											<a href="#" class="post-link-url"><i class="fa fa-link"></i><?php the_title?></a>
										</div>

										<div class="post-footer">
											<span><i class="fa fa-clock-o"></i> <?php the_date('d M, Y'); ?> </span>

											<span><?php comments_popup_link('<i class="fa fa-comments-o"></i> 0','<i class="fa fa-comments-o"></i> 1','<i class="fa fa-comments-o"></i> %'); ?></span>
										</div>

								<?php elseif(has_post_format( 'quote' )) : ?>

										<div class="post-header">
											<h2 class="post-title"><?php the_title(); ?></h2>
										</div>

										<div class="post-desc">
											<?php the_content(); ?>									
										</div>

										<div class="post-footer">
											<span><i class="fa fa-clock-o"></i> <?php the_date('d M, Y'); ?> </span>

											<span><?php comments_popup_link('<i class="fa fa-comments-o"></i> 0','<i class="fa fa-comments-o"></i> 1','<i class="fa fa-comments-o"></i> %'); ?></span>
										</div>
									
								<?php elseif(has_post_format( 'gallery' )) : ?>
								
										<div class="post-header">
											<h2 class="post-title"><?php the_title(); ?></h2>
										</div>

										<?php if( has_post_thumbnail() ) : ?>
										<div class="gallery">
											<?php the_post_thumbnail( 'full', array('class'=>'img-responsive') ); ?>
										</div>
										<?php endif; ?>

										<div class="post-footer">
											<span><i class="fa fa-clock-o"></i> <?php the_date('d M, Y'); ?> </span>

											<span><?php comments_popup_link('<i class="fa fa-comments-o"></i> 0','<i class="fa fa-comments-o"></i> 1','<i class="fa fa-comments-o"></i> %'); ?></span>
										</div>
									
								<?php elseif(has_post_format( 'video' )) : ?>
								
										<div class="post-header">
										<h2 class="post-title"><?php the_title(); ?></h2>
										</div>

										<div class="post-desc">
											<?php the_content(); ?>									
										</div>

										<div class="post-footer">
											<span><i class="fa fa-clock-o"></i> <?php the_date('d M, Y'); ?> </span>

											<span><?php comments_popup_link('<i class="fa fa-comments-o"></i> 0','<i class="fa fa-comments-o"></i> 1','<i class="fa fa-comments-o"></i> %'); ?></span>
										</div>
									
								<?php else : ?>
									<div class="post-header">
										<h2 class="post-title">
											<a href="<?php the_permalink(); ?>">
												<?php the_title(); ?>
											</a>
										</h2>
										
										<?php if(is_sticky()) : ?>
										<span class="pin_post"></span>
										<?php endif; ?>
									</div>

									<?php if( has_post_thumbnail() ) : ?>
									<div class="post-thumbnail">
										<?php the_post_thumbnail( 'full', array('class'=>'img-responsive') ); ?>
									</div>
									<?php endif; ?>

									<div class="post-desc">
										<?php if(has_excerpt()) : ?>
											<p><?php the_excerpt(); ?></p>
										<?php else : ?>
											<?php the_content(__('Continue reading...','coronavirusnetwork')); ?>
										<?php endif; ?>										
									</div>

									<div class="post-footer">
										<span><i class="fa fa-clock-o"></i> <?php the_date('d M, Y'); ?> </span>

										<span><?php comments_popup_link('<i class="fa fa-comments-o"></i> 0','<i class="fa fa-comments-o"></i> 1','<i class="fa fa-comments-o"></i> %'); ?></span>
									</div>
									
								<?php endif; ?>
							</div>
						<?php endwhile; ?>
					</div>
				<?php endif; ?>
			 </div><!-- #content container  -->
 
			 <!-- Getting right sidebar -->
			 <?php get_sidebar(); ?><!-- End Right sidebar -->

		 </div>
	 </div>
 </div>
 <!-- End content area -->
 
 <!-- Footer -->
 <?php get_footer();