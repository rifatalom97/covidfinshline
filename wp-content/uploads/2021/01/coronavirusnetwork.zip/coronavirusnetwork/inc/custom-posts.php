<?php
/*
* Creating a function to create our CPT
*
* @author Rifat
* @package coronavirusnetwork
*/
function coronavirusnetwork_custom_post_types() {
    // HOme
    $landing_page_labels = array(
        'name'               => esc_html__( 'Landing Page', 'coronavirusnetwork' ),
        'singular_name'      => esc_html__( 'Landing Page', 'coronavirusnetwork' ),
        'add_new'            => esc_html__( 'Add Widget', 'coronavirusnetwork' ),
        'add_new_item'       => esc_html__( 'Add New Widget', 'coronavirusnetwork' ),
        'edit_item'          => esc_html__( 'Edit Widget', 'coronavirusnetwork' ),
        'new_item'           => esc_html__( 'New Widget', 'coronavirusnetwork' ),
        'all_items'          => esc_html__( 'All Widgets', 'coronavirusnetwork' ),
        'view_item'          => esc_html__( 'View Widget', 'coronavirusnetwork' ),
        'search_items'       => esc_html__( 'Search Widgets', 'coronavirusnetwork' ),
        'not_found'          => esc_html__( 'Nothing found', 'coronavirusnetwork' ),
        'not_found_in_trash' => esc_html__( 'Nothing found in Trash', 'coronavirusnetwork' ),
        'parent_item_colon'  => '',
    );
    $landing_page_args = array(
        'labels'             => $landing_page_labels,
        'public'             => true,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'can_export'         => true,
        'show_in_nav_menus'  => false,
        'show_in_admin_menus'=> false,
        'query_var'          => false,
        'has_archive'        => false,
        'rewrite'            => false,
        'capability_type'    => 'post',
        'hierarchical'       => false,
        'menu_position'      => null,
        'menu_icon'          => 'dashicons-images-alt2',
        'supports'           => array( 'title', 'custom-fields', 'page-attributes'),
    );
    // register Partners
    register_post_type( 'landing_page', $landing_page_args );
}
    
/* Hook into the 'init' action so that the function */
add_action( 'init', 'coronavirusnetwork_custom_post_types', 0 );