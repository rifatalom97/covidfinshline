(function() {
    tinymce.PluginManager.add('mybutton', function( editor, url ) {

        editor.addButton( 'mybutton3', {
            text: 'Quote-Button',
            icon: false,
            onclick: function() {
                editor.windowManager.open( {
                    title: 'Request Quote',
                    body: [
                        {
                            type: 'textbox', // editor
                            multiline: true,
                            name: 'btn_text',
                            label: 'Button text',
                            minWidth: 300,
                            value: 'Request A Quick Quote'
                        },
                        {
                            type   : 'textbox',
                            name   : 'url',
                            label: 'Url',
                            minWidth: 300,
                            value : 'https://viccoronavirusnetwork.wufoo.com/forms/zr9zcrc1lte6eq/' // Sets the default
                        }
                    ],
                    onsubmit: function( e ) {
                        editor.insertContent( '[quote_button url="' + e.data.url + '" title="' + e.data.btn_text + '" /]');
                    }
                });
            },
        });



        editor.addButton( 'mybutton2', {
            text: 'Support',
            icon: false,
            onclick: function() {
                editor.windowManager.open( {
                    title: 'Support Popup',
                    body: [
                        {
                            type: 'textbox', // editor
                            multiline: true,
                            name: 'content',
                            label: 'Text',
                            minWidth: 300,
                            minHeight: 100,
                            value: 'Let’s support your business, solve your problems and reduce your costs'
                        },
                        {
                            type   : 'textbox',
                            name   : 'url',
                            label  : 'Url',
                            value : 'https://viccoronavirusnetwork.wufoo.com/forms/zr9zcrc1lte6eq/' // Sets the default
                        }
                    ],
                    onsubmit: function( e ) {
                        editor.insertContent( '[support url="' + e.data.url + '" text="' + e.data.content + '"]');
                    }
                });
            },
        });

        // Button for history shortcode
        editor.addButton( 'mybutton', {
            text: 'History Timeline',
            icon: false,
            onclick: function() {
                editor.insertContent( '[history /]');
            },
        });



    });
})();




jQuery(document).ready(function($){
    $(document).on('click', '.mce-my_upload_button', upload_image_tinymce);

    function upload_image_tinymce(e) {
        e.preventDefault();
        var $input_field = $('.mce-my_input_image');
        var custom_uploader = wp.media.frames.file_frame = wp.media({
            title: 'Add Image',
            button: {
                text: 'Add Image'
            },
            multiple: false
        });
        custom_uploader.on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            $input_field.val(attachment.url);
        });
        custom_uploader.open();
    }
});