<?php
/**
 * Landing template about section
 * 
 * @author Rifat
 * 
 * @package coronavirusnetwork
 * 
 */
$slug               = get_post_meta( get_the_ID(), 'landing_page_sections', true );
$mission_title        = get_post_meta( get_the_ID(), 'mission_title', true );
$mission_details      = get_post_meta( get_the_ID(), 'mission_details', true );
$repeatable_missions      = get_post_meta( get_the_ID(), 'repeatable_missions', true );

?>
<section class="landing_section <?= $slug; ?>_section" id="<?= $slug; ?>_section">
    <div class="container">
        <div class="landing_container">
            <?php if($mission_title !='') : ?>
                <h2 class="section_title">
                    <?= esc_html($mission_title); ?>
                </h2>
            <?php endif; ?>
            
            <?php if($mission_details) : ?>
                <div class="row">
                    <div class="col-md-12 section_details">
                        <?= apply_filters('the_content', $mission_details); ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(is_array($repeatable_missions) && count($repeatable_missions)) : ?>
                <div class="missions">
                    <?php foreach($repeatable_missions as $mission) : ?>
                        <div class="single_mission">
                            <?php if(isset($mission['single_mission_title']) && $mission['single_mission_title']) : ?>
                            <h4 class="mission_title"><?= nl2br(strip_tags($mission['single_mission_title'], '<b>, <strong>')); ?></h4>
                            <?php endif; ?>

                            <?php if(isset($mission['single_mission_icon']) && $mission['single_mission_icon']) : ?>
                                <img src="<?= esc_url( $mission['single_mission_icon'] ); ?>" alt="<?= esc_html($mission['single_mission_title']); ?>">
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>