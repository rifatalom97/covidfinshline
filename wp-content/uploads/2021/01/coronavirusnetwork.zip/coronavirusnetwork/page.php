<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package coronavirusnetwork
 */

 // Loading header
get_header(); ?>



<?php
	$sidebar = get_post_meta(get_the_ID(), 'page_sidebar', true);
?>
<!-- Content-area -->
<div class="content-area page_area">

	
	<div class="page-header">
		<div class="container text-center">
			<h2 class="page_title"><?php the_title(); ?></h2>
		</div>
	</div>

	<?php if( is_elementor_active() ) : 
		while ( have_posts() ) : the_post();
		the_content();
		endwhile;
	else : ?>
	<div class="container">
		<div class="row">

			<!-- Content container -->
			<div class="content <?php if( is_active_sidebar( 'sidebar' ) && $sidebar != 'fullwidth') : ?>col-md-8 col-lg-9 blog-post-area<?php else : ?> col-md-12 <?php echo $sidebar; endif; ?>">
				<?php
					if ( have_posts() ) :
						/* Start the Loop */
						while ( have_posts() ) : the_post();


						if(is_elementor_active()){
							the_content();
						}else{

							if ( 0 == get_post_meta(get_the_ID(), 'page_title', true) ) :
								?>
								<div>
									<h2 class="page-title"><?php single_post_title(); ?></h2>
								</div>
								<?php
							endif;

							if( has_post_thumbnail() ) : ?>
								<div class="featured-image">
									<?php the_post_thumbnail('full', array('class'=>'img-responsive')); ?>
								</div>
							<?php endif; ?>
							
							<div class="page-content">
								<?php the_content(); ?>
							</div>

						<?php } endwhile;
					endif;
				?>
			</div><!-- #main -->

			
			<?php if( 'sidebar' == $sidebar || '' == $sidebar ) : ?>
				<!-- Getting right sidebar -->
				<?php get_sidebar('right'); ?>
				<!-- End Right sidebar -->
			<?php endif; ?>
			
		</div>
	</div>
	<?php endif; ?>
</div><!-- #primary -->
<!-- End content area -->

<!-- Footer -->
<?php
get_footer();
