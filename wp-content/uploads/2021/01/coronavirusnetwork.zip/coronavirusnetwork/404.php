<?php
/**
 * Home template
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 * @author Rifat
 * @package coronavirusnetwork
 */

 // Loading header
 get_header();  ?>

 <!-- Content-area -->
 <div class="content-area">
	 <div class="container">
		 <div class="row"> 

			 <!-- Content container -->
			 <div class="col-md-12">
			 
					<div class="not-found">

						<h1><?php _e( '404', 'coronavirusnetwork' ); ?></h1>

						<h3><?php _e( "OOP'S SORRY WE CAN'T FIND THAT PAGE!", 'coronavirusnetwork' ); ?></h3>

						<P><?php _e( "Either something went wrong Or the page doesn't exists anymore.", 'coronavirusnetwork' ); ?></P>
					</div>
					
             </div><!-- #content container  -->
		 </div>
	 </div>
 </div>
 <!-- End content area -->
 
 <!-- Footer -->
 <?php get_footer();