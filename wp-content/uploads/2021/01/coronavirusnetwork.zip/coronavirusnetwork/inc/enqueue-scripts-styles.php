<?php
/**
 * Enqueue scripts and styles.
 */
define('D_VERSION',time());
function coronavirusnetwork_scripts( $scct ) {
	wp_enqueue_script('jquery'); // Jquery By Default 
		
	// loading Google webfont open sans
	wp_enqueue_style( 'google-webfont-open-sans', 'https://fonts.googleapis.com/css?family=Open+Sans:300,400' );
	// loading icon font awesome
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/assets/css/fontawesome.min.css', [], '4.7.0' );
	// Loading bootstrap
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', [], '3.0.1' );

	// Loading owl-carousel
	wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/assets/owl-carousel/assets/owl.carousel.min.css', [], '2.3.4' );
	wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/assets/owl-carousel/assets/owl.theme.default.min.css', [], '2.3.4' );

	// Load default stylesheet
	wp_enqueue_style( 'coronavirusnetwork-style', get_stylesheet_uri() );



	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Bootstrap script
	wp_enqueue_script( 'bootstrap-script', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '3.1.1', true );
	
	// Owl-carousel script
	wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/assets/owl-carousel/owl.carousel.min.js', array('jquery'), '2.3.4', true );


	// Custom initial script
	wp_enqueue_script( 'coronavirusnetwork-custom', get_template_directory_uri() . '/assets/js/custom.js', array('jquery'), '1.0', true );

}
add_action( 'wp_enqueue_scripts', 'coronavirusnetwork_scripts' );
