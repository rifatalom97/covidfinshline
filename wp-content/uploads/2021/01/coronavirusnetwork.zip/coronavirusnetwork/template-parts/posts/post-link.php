<?php
  $postClass = is_active_sidebar( 'sidebar' )? 'col-md-12 col-lg-6' : 'col-md-6';
?>
<div <?php post_class("blog-post index-blog-post {$postClass} clearfix"); ?> id="post-<?php the_ID(); ?>">
  <div class="post-inner-container">
      <h3 class="post-title link" ><i class="fa fa-link"></i> <?php echo strip_tags(get_the_content(), '<a>'); ?></h3>
    </div>
</div>