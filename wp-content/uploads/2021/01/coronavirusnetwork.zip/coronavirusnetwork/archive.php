<?php
/**
 * Template for archive
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @author Rifat
 * @package coronavirusnetwork
 */

 // Loading header
 get_header();  ?>

 <!-- Content-area -->
 <div class="content-area">
	 <div class="container">
		 <div class="row"> 
	
				<!-- Content container -->
				<div class="<?php if( is_active_sidebar( 'sidebar' ) ) : ?>col-md-8 col-lg-9<?php else : ?> col-md-12 <?php endif; ?>">
				<?php
					$type = $query = '';

					if( is_category() ){
						$type = 'cat';
						$query = get_query_var('cat');
					}elseif(is_tag()){
						$type = 'tag';
						$query = get_query_var('tag');
					}elseif( is_search() ){
						$type = 's';
						$query	= get_query_var('s');
					}else{
						if( !is_home() ){
							if( get_query_var('monthnum') ){

								$type = 'monthnum/';
								$query = get_query_var('monthnum') . '/';
								
							}elseif( get_query_var('year') ){

								$type .= 'year';
								$query .= get_query_var('year');
								
							}
						}
					}
				?>
					<?php if ( have_posts() ) : ?>
						<?php
							the_archive_title( '<h1 class="page-title search_title text-center text-mute">', '</h1>' );
						?>

						<?php
							$postClass = is_active_sidebar( 'sidebar' )? 'col-md-6' : 'col-md-4';
						?>
						<div class="blog-posts row">
							<?php  while ( have_posts() ) : the_post();
							
									get_template_part( 'template-parts/posts/post', get_post_format() );

								endwhile; ?>
						</div>
					<?php else : ?>
						<h1 class="page-title no-post-found text-center"><?php _e('No archive post found', 'coronavirusnetwork'); ?></h1>
					<?php endif; ?>

					<!-- Load more -->
					<?php if(have_posts()) : ?>
						<div class="col-md-12 text-center">
							<p id="load_more_button" data-url="<?= admin_url('admin-ajax.php'); ?>" data-type="<?= $type; ?>" data-query="<?= $query; ?>" data-page="1" style="display: none;">
								<img src="<?= get_template_directory_uri(); ?>/assets/img/loading.gif" width="" height="" >
								<span>Loading...</span>
							</p>
						</div>
					<?php endif; ?><!-- #end load more -->
					
				</div><!-- #content container  -->
             
             <!-- Getting right sidebar -->
			 <?php get_sidebar(); ?><!-- End Right sidebar -->
		 </div>
	 </div>
 </div>
 <!-- End content area -->
 
 <!-- Footer -->
 <?php get_footer();