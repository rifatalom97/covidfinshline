<?php
/**
 * Landing template contact section
 * 
 * @author Rifat
 * 
 * @package coronavirusnetwork
 * 
 */
$slug               = get_post_meta( get_the_ID(), 'landing_page_sections', true );
$contact_title        = get_post_meta( get_the_ID(), 'contact_title', true );
$contact_details      = get_post_meta( get_the_ID(), 'contact_details', true );
$contact_form_show      = get_post_meta( get_the_ID(), 'contact_form_show', true );
$contact_download_title      = get_post_meta( get_the_ID(), 'contact_download_title', true );
$contact_download_file      = get_post_meta( get_the_ID(), 'contact_download_file', true );
$contact_footer_text      = get_post_meta( get_the_ID(), 'contact_footer_text', true );

?>
<section class="landing_section <?= $slug; ?>_section" id="<?= $slug; ?>_section">
    <div class="container">
        <div class="landing_container">
            <?php if($contact_title !='') : ?>
                <h2 class="section_title">
                    <?= esc_html($contact_title); ?>
                </h2>
            <?php endif; ?>
            
            <?php if($contact_details != '') : ?>
                <div class="row">
                    <div class="col-md-12 section_details">
                        <?= apply_filters('the_content', $contact_details); ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if($contact_form_show) : ?>
                <div class="contact_form">
                    <div class="row">
                        <div class="col-md-12">
                            <form action="<?php echo admin_url('admin-ajax.php'); ?>" method="POST" class="custom_contact_form">

                                <h3 class="success_msg"></h3>

                                <?php wp_nonce_field('custom_contact_form_handle','rcustom_contact_form_handle'); ?>
                                <input name="action" value="custom_contact_form_handle" type="hidden">

                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="name" id="" class="form-control" placeholder="<?php _e('Name','coronavirusnetwork'); ?>" autocomplete='off' required>
                                            <p id="name_error" class="error txt-danger txt-small"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="email" name="email" id="" class="form-control" placeholder="<?php _e('Email','coronavirusnetwork'); ?>" autocomplete='off' required>
                                            <p id="email_error" class="error txt-danger txt-small"></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <textarea name="message" id="" cols="30" rows="10" class="form-control" placeholder="<?php _e('Message','coronavirusnetwork'); ?>" autocomplete='off' required></textarea>
                                    <p id="message_error" class="error txt-danger txt-small"></p>
                                </div>

                                <input name="website" type="text" class="form-control" style="display:none" />

                                <button type="submit" class="btn btn-primary btn-lg submit_button"><?php _e('SUBMIT','coronavirusnetwork'); ?></button>
                            </form>
                        </div>
                    </div> 
                </div>
            <?php endif; ?>
            
            <?php if($contact_download_title) : ?>
                <div class="file_download">
                    <div class="row">
                        <div class="col-md-12">
                            <a href="<?= esc_url($contact_download_file); ?>">
                                <?= nl2br($contact_download_title); ?>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            

            <?php if($contact_footer_text) : ?>
                <div class="landing_footer_text">
                    <p>
                        <span>
                        <?= $contact_footer_text; ?>
                        </span>
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>