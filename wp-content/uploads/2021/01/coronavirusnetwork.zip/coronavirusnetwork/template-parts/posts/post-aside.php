<?php
  // for half width
  //$postClass = is_active_sidebar( 'sidebar' )? 'col-md-12 col-lg-6' : 'col-md-6';
  // for full width
  $postClass = is_active_sidebar( 'sidebar' )? 'col-md-12 col-lg-12' : 'col-md-12';
?>
<div <?php post_class("blog-post index-blog-post {$postClass} clearfix"); ?> id="post-<?php the_ID(); ?>">

    <div class="post-inner-container aside">
      <h3 class="post-title" ><a href="<?= get_the_permalink(); ?>"><?php the_title(); ?></a></h3>

      <?php if( has_post_thumbnail() ) : ?>
      <div class="thumbnail pull-left">
        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'post-thumb', array('class'=>'img-responsive') ); ?></a>
      </div>
      <?php endif; ?>

      <div class="post-description">
          <?php the_excerpt(); ?>
      </div>
    </div>
</div>