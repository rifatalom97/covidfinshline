<?php
/**
 * The sidebar containing the footer widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package coronavirusnetwork
 */
if ( ! is_active_sidebar( 'sidebar-bottom' ) ) { return; } 

dynamic_sidebar( 'sidebar-bottom' );

?>