<?php
/**
 * coronavirusnetwork Theme header
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package coronavirusnetwork
 */
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"  <?php language_attributes(); ?>> <!--<![endif]-->
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="profile" href="https://gmpg.org/xfn/11">
        <!-- Description -->
        <meta name="description" content="<?= get_bloginfo( 'description', 'display' ); ?>"><!-- Description -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
        <?php endif; ?>
        <!-- WP Head -->
        <?php wp_head(); ?>
    </head>


   <?php 
        $classes = array();

        if( 'page' === get_post_type() ) {
            $btag = get_post_meta( $post->ID, 'gray_color_page', true );

            if( ! empty( $btag ) ) {
                $classes[] = 'gray_color_page';
            }
        }
    ?>
    <body <?php body_class( $classes ); ?>>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <!-- Add your site or application content here -->
        <header class="clearfix">
            <div class="container">
                <div class="row">
                    <!-- Logo -->
                    <div class="col-sm-4 col-md-4 col-lg-3 col-xs-5 logo-area">
                        <div class="logo">
                            <?php if(has_custom_logo()) : ?>
                                <?php the_custom_logo(); ?>
                            <?php else : ?>
                            <a href="<?= site_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo.png" alt="<?php bloginfo('name'); ?>" class="img-responsive" height="134" width="262"></a>
                            <?php endif; ?>
                        </div>
                    </div><!-- End Logo -->

                    <div class="col-sm-8 col-md-8 col-lg-9 col-xs-7 menu-area">
                        <?php 
                            $mark_last_menu = get_theme_mod( 'mark_last_menu' );
                        ?>
                        <div class="main-menu <?= $mark_last_menu? 'mark-last' : false; ?>">
                            <div class="mobile-menu visible-xs visible-sm">
                                <div class="col-md-12">
                                    <h4 class="pull-left visible-xs"><?php _e('MENU', 'coronavirusnetwork'); ?></h4>
                                    <i class="fa fa-bars pull-right"></i>
                                </div>
                            </div>
                            <?php wp_nav_menu(array( 
                                'theme_location'    => 'primary-menu',
                                'menu_id'           => 'primary-menu',
                                'menu_class'        => 'menu',
                                'container'         => 'nav',
                                'container_class'   => 'nav pull-right',
                                'depth'             => 2,
                                'fallback_cb' => '__return_false'
                            )); ?>
                        </div>

                    </div>
                </div>
            </div>
        </header>
