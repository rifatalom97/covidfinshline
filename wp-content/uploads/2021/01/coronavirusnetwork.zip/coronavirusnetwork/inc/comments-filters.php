<?php

// Add Class to Gravatar
add_filter('get_avatar', 'twbs_avatar_class');
function twbs_avatar_class($class) {
	$class = str_replace("class='avatar", "class='avatar img-circle media-object", $class);
	return $class;
}

// Add Class to Comment Reply Link
add_filter('comment_reply_link', 'twbs_reply_link_class');
function twbs_reply_link_class($class){
	
	$class = str_replace("class='comment-reply-link", "class='comment-reply-link btn btn-default btn-sm", $class);
	
	$class = str_replace("Reply", '<i class="fa fa-reply"></i> Replay', $class);
	
	return $class;
}


// filter comment fields
add_filter( 'comment_form_default_fields', 'comment_formsr' );
function comment_formsr( $fields ){
	$author = '
	<div class="comment-form-author form-group">
		<div class="row">
			<div class="col-sm-12">
				<input id="author" name="author" type="text" value="" size="30" maxlength="100" required="required" class="form-control" placeholder="' . _x( 'Name*', 'coronavirusnetwork' ) . '">
			</div>
		</div>
	</div>
	';

	$email = '
	<div class="comment-form-email form-group">
		<div class="row">
			<div class="col-sm-12">
				<input id="email" name="email" type="email" value="" size="30" maxlength="100" aria-describedby="email-notes" required="required" class="form-control" placeholder="' . _x( 'Email*', 'coronavirusnetwork' ) . '">
			</div>
		</div>
	</div>
	';

	$url = '
	<div class="comment-form-url form-group">
		<div class="row">
			<div class="col-sm-12">
			<input id="url" name="url" type="url" value="" size="30" maxlength="200" class="form-control" placeholder="' . _x( 'Website', 'coronavirusnetwork' ) . '">
			</div>
		</div>
	</div>
	';


	$fields['author'] 				= $author;
	$fields['email']				= $email;
	$fields['url'] 					= $url;

	return $fields;
}

// Filtering comment textarea
add_filter( 'comment_form_defaults', 'comment_formtext_area' );
function comment_formtext_area( $comment_field ){

	$field = '
	<div class="comment-form-comment form-group">
		<div class="row">
			<div class="col-sm-12">
			<textarea id="comment" name="comment" cols="45" rows="8" aria-describedby="form-allowed-tags" aria-required="true" required="required" class="form-control" placeholder="' . _x( 'Comment*', 'coronavirusnetwork' ) . '"></textarea>
			</div>
		</div>
	</div>
	';

	$comment_field['comment_field'] 	= $field;
	$comment_field['class_submit'] 		= 'submit btn btn-primary btn-lg';

	return $comment_field;
}


// Re-arrange fields
add_filter( 'comment_form_fields', 'wpb_move_comment_field_to_bottom' );
function wpb_move_comment_field_to_bottom( $fields ) {
	$comment_field = $fields['comment'];
	unset( $fields['comment'] );
	
	$fields['comment'] = $comment_field;
	
	return $fields;
}