<?php
/**
 * coronavirusnetwork functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @author Rifat
 * @package coronavirusnetwork
 */


// after theme setups
require_once dirname(__FILE__) . '/inc/after-theme-setup.php';



// Regiset widgets
require_once 'inc/widgets/register-widgets.php';





// Custom Posts
require_once dirname(__FILE__) . '/inc/custom-posts.php';

// Custom Taxonomy
//require_once dirname(__FILE__) . '/inc/custom-taxonomy.php';




// Loading script and styles
require_once dirname(__FILE__) . '/inc/enqueue-scripts-styles.php';


/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';




/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';




/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}





// Including CMB2 metabox library
if( file_exists( dirname(__FILE__) . '/lib/cmb2/init.php' ) )
{
	require_once  dirname(__FILE__) . '/lib/cmb2/init.php';

	require_once  dirname(__FILE__) . '/inc/metabox/metabox.php'; 
}



// Requring custom ajax requests
if( file_exists( dirname(__FILE__) . '/inc/custom-ajax-request.php' ) )
{
	require_once  dirname(__FILE__) . '/inc/custom-ajax-request.php';
}




// excerpt
// function custom_excerpt_length( $length ) {
// 	return 50;
// }
// add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );
function new_excerpt_more($more) {
    return '... <a href="'.get_the_permalink().'">'.__('Read more','coronavirusnetwork').'</a>';
}
add_filter('excerpt_more', 'new_excerpt_more', 21 );



// Get Post type Link
function grab_post_url(){
	$content = get_the_content();

	if( !preg_match( '/<a\s[^>]*?href=[\'"](.+?)[\'"]/i', $content, $links ) ){
		return false;
	}

	return $links[1];
}


// Fix get-attachment-image
function alter_att_attributes_wpse_102079($attr) {
	$attr['class'] .= ' img-responsive';
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'alter_att_attributes_wpse_102079');



// Filter textWidget
add_filter( 'widget_text', 'do_shortcode' );


// Comments filters
require_once dirname(__FILE__) . '/inc/comments-filters.php';



// Shortcodes
//require_once dirname(__FILE__) . '/inc/custom-shortcodes.php';




function add_async_attribute($tag, $handle) {
    if ( 'my-js-handle' !== $handle )
        return $tag;
    return str_replace( ' src', ' async="async" src', $tag );
}
add_filter('script_loader_tag', 'add_async_attribute', 10, 2);



// menu filter for contact popupbox widget

function push_landing_page_nav_menu($items, $args) {
	$sections = get_posts(array( 'post_type' =>'landing_page', 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby'=>'menu_order id', 'order'=>'ASC' ));
	
	$show_sections_menu 	= get_theme_mod( 'visibile_hm_sections_menu', true );

	$items = str_replace('menu-item','menu-item external',$items);

	if( $args->theme_location == 'primary-menu' && count($sections) && 1 == $show_sections_menu ){
		$custom_menus = '';
		
		foreach($sections as $section){
			$slug = get_post_meta( $section->ID, 'landing_page_sections', true );

			// if($slug == 'mission' && $show_mission_menu != 1) continue;

			$custom_menus .= '<li id="menu-item-hm-section" class="menu-item hm-section-menu">
								<a href="'.site_url().'/#'.$slug.'_section"> ' . strip_tags($section->post_title) . ' </a>
							</li>';
		}
		$items = $custom_menus . $items;
	}
	return $items;
}
add_filter('wp_nav_menu_items', 'push_landing_page_nav_menu', 10, 2);





// is elementor active
function is_elementor_active(){
	global $post;
	return \Elementor\Plugin::$instance->db->is_built_with_elementor($post->ID);
}

// update_option( 'home', 'http://coronavirusnetwork.local' );
// update_option( 'siteurl', 'http://coronavirusnetwork.local' );