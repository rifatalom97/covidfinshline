<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @author Rifat
 * @package coronavirusnetwork
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>
<div class="clearfix"></div>
<div class="row">
<div id="comments" class="comments-area col-md-12 ">
	<?php
	// You can start editing here -- including this comment!
	if ( have_comments() ) : ?>

		<h3 class="comment-header">
			<?php
				$coronavirusnetwork_comment_count = get_comments_number();
				if ( '1' === $coronavirusnetwork_comment_count ) {
					printf(
						/* translators: 1: title. */
						esc_html__( 'One Comment', 'coronavirusnetwork' )
					);
				} else {
					printf( // WPCS: XSS OK.
						/* translators: 1: comment count number, 2: title. */
						esc_html( _nx( '%1$s Comments', '%1$s Comments', $coronavirusnetwork_comment_count, 'Comments title', 'coronavirusnetwork' ) ),
						number_format_i18n( $coronavirusnetwork_comment_count ),
						'<span>' . get_the_title() . '</span>'
					);
				}
			?>
		</h3><!-- .comment-header -->
		
		<?php
			function coronavirusnetwork_customize_comment_list($comment, $args, $depth) {

			$tag = ( 'div' === $args['style'] ) ? 'div' : 'li'; 

			$row = (0 != $comment->comment_parent)? '' : 'row'; ?>
				
			<<?php echo $tag; ?> id="comment-<?php comment_ID(); ?>" <?php comment_class($row); ?>>

					<div class="col-md-2 col-sm-2 <?= (0 != $comment->comment_parent)? 'col-md-offset-1 col-sm-offset-0 ' : false; ?>hidden-xs">
						<figure class="thumbnail">
						<?php if ( 0 != $args['avatar_size'] ) echo get_avatar( $comment, $args['avatar_size'], null, null, array('class'=>'img-responsive') ); ?>
						<figcaption class="text-center"><?php echo get_comment_author($comment->comment_ID); ?></figcaption>
						</figure>
					</div>

					<div class="<?= (0 != $comment->comment_parent)? 'col-md-9 col-sm-10' : 'col-md-10 col-sm-10'; ?>">
						<div class="panel panel-default arrow left">
							<div class="panel-body">
								<div class="text-left">
									<div class="comment-user"><i class="fa fa-user"></i> <?php echo get_comment_author($comment->comment_ID); ?></div>
									<time class="comment-date" datetime="<?php comment_time( 'c' ); ?>"><i class="fa fa-clock-o"></i> <?php printf( _x( '%1$s at %2$s', '1: date, 2: time' ), get_comment_date(), get_comment_time() ); ?></time>
								</div>

								<!-- .comment-metadata -->
								<?php if ( '0' == $comment->comment_approved ) : ?>
								<p class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.' ); ?></p>
								<?php endif; ?>

								<div class="comment-post">
									<?php comment_text(); ?>
								</div>
								
								<?php
									comment_reply_link( array_merge( $args, array(
									'add_below' => 'div-comment',
									'depth'     => $depth,
									'max_depth' => $args['max_depth'],
									'before'    => '<p class="text-right">',
									'after'     => '</p>'
									) ) );
								?>
							</div>
						</div>
					</div>
			<!-- .comment-body -->
		<?php } ?>



		<section class="comment-list">
			<?php
				$args = array(
					'format'		=> 'html5',
					'avatar_size'	=> 64,
					'style'			=> 'div',
					'callback'		=> 'coronavirusnetwork_customize_comment_list',
				);
				wp_list_comments( $args );
			?>
		</section><!-- .comment-list -->

		<?php if( get_the_comments_navigation() ) : ?>
			<ul class="pager">
				<li class="previous"><?php previous_comments_link( '&larr; Older' ) ?></li>
				<li class="next"><?php next_comments_link('Newer &rarr;') ?></li>
			</ul>
		<?php endif; ?>
		
		<?php //the_comments_navigation();

		// If comments are closed and there are comments, let's leave a little note, shall we?
		if ( ! comments_open() && get_comments_number() ) : ?>

			<p class="no-comments bg-danger" style="padding: 15px;border-radius: 4px;"><?php esc_html_e( 'Comments are closed.', 'coronavirusnetwork' ); ?></p>
		
		<?php endif;

	endif; // Check for have_comments().


	?>

	<div class="clearfix">
		<?php comment_form(); ?>
	</div>
</div><!-- #comments -->
</div>